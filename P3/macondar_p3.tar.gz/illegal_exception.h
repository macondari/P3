#ifndef ILLEGAL_EXCEPTION_H
#define ILLEGAL_EXCEPTION_H

class illegal_exception {
public:
    const char* illegal() const;
};

#endif // ILLEGAL_EXCEPTION_H
